#include <iostream>
#include <stdlib.h>
#include <cstdlib>

#define ERROR 0.0001 //error tolerance level given in the question
using namespace std;

//The function is x^4 + x^2 - 4x
double function(double x) {
	return x * x * x * x + x * x - 4 * x;
}

//First derivative of the function 
//Necessary for the Newton's method
double firstDerivative(double x) {
	return 4 * x * x * x + 2 * x - 4; //4x^3 + 2x -4
}

//Second derivative of the function 
//Necessary for the Newton's method
double secondDerivative(double x) {
	return 12 * x * x + 2; //12x^2 + 2
}


void newton(double x) { //The newton approximation method to find the solution

	double val = firstDerivative(x) / secondDerivative(x); //the value of f'(x)/f''(x)
	int i = 1; //to count the iterations

	cout << "Iteration[i]\tx[i]\t\tf(x[i])\t\tf'(x[i])\tf''(x[i])\tx[i+1]" << endl; //the headers for the output

	while (abs(val) >= ERROR) { //executes repeatedly until the difference is smaller than the epsilon tolerance level
		val = firstDerivative(x) / secondDerivative(x); //the new value of f'(x)/f''(x)
		cout << i << "\t\t" << x << "\t\t" << function(x) << "\t\t" << firstDerivative(x) << "\t"; 
		if (i < 6) cout << "\t"; //for a more aligned C++ output
		cout << secondDerivative(x) << "\t\t";
		x = x - val; // x(i+1) = x(i) - f'(x) / f''(x)
		cout << x << endl; //prints the next x to the right-most column of the output
		i++;
	}

	cout << endl << "The approximate solution by Newton's method is " << x << endl;
}

int main() {
	cout.precision(4);
	double x_initial = 0; // initial value is 0 as given in the question
	newton(x_initial);
	return 0;
}

