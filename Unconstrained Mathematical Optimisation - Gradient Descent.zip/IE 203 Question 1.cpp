﻿#include <iostream>
using namespace std;

double x = 0.5;
double y = 0.5;
const double learning_rate = 0.2; // step size for gradient ascent
//I used a constant value of t=0.2 because otherwise it would be computationally costly
//Finding the derivative of t analytically in each iteration would be very time-consuming
//0.2 is an ideal step size (ideal value of t) for this question
const int max_iterations = 34; // maximum number of iterations

int main() {
    cout.precision(2); //this way the results will have only two digits after zeros, so they won't occupy the entire screen
    cout << "Iteration\tx_i\t\t\tG[f(x')]\t\tx'+tG[f(x')]\t\t\t\tt*\t\tx'+t*G[f(x')]" << endl;
    cout << "-----------------------------------------------------------------------------------------------------------------------------------" << endl;
    for (int i = 1; i <= max_iterations; i++) {
        //Computing the gradient of the function at the current position (x, y)
        double gradient_x = 2*y - 2*x;
        double gradient_y = 2*x + 2 - 4*y;

        std::cout << i << "\t\t(" << x << ", " << y << ")\t\t"; 
        if (i >= 30) cout << "\t"; //for a better aligned tabulated output
        cout<<"(" << gradient_x << "," << gradient_y << ")";
        if (i == 1) cout << "\t"; //for a better aligned tabulated output
        cout << "\t\t(" << x << "+" << gradient_x << "t, " << y << "+ " << gradient_y << "t)\t\t"; 
        if (i == 1 || i == 2 || i >= 30) cout << "\t"; //for a better aligned tabulated output
        cout << learning_rate;
        // Move in the direction of the gradient
        x += learning_rate * gradient_x;
        y += learning_rate * gradient_y;
        cout << "\t\t(" << x << ", " << y << ")" << endl;
    }

    //It is important to note that the tabulated results may not look aligned if the parameters are changed
    //This is due to the output format of C++
    //Still, my algorithm gives correct approximations with different parameters
    //For instance, if we make the learning rate 0.1 and the number of iterations 100, we again reach the optimum point x=1, y=1
    //It is not a good approach to increase the learning rate too much, as it may lead to the missing of the optimum point
    //To decrease the learning rate too much is computationally ineffective, as we need much more iterations to reach the optimum

    cout << endl << "Local maximum found at x = " << x << ", y = " << y << endl;
    return 0;
}

