#include <iostream>
#include <iomanip>

using namespace std;

#define ERROR 0.005 //defining the epsilon error given in the question

//The function is x^4 + x^2 - 4x

double function(double x) {
	return x * x * x * x + x * x - 4 * x; //the original function
}
double derivative(double x) {
	return x * x * x * 4 + x * 2 - 4; //the derivative of the function to apply bisection method
}

void bisection(double x_lower, double x_upper) {
	if (derivative(x_lower) * derivative(x_upper) >= 0) { //to make sure that we have a local optimum in the interval 
		cout << "Wrong interval assumption" << endl; //because the derivative must change its sign in the interval
		return;
	}

	double x_mid = x_lower;
	cout << "Iteration\tf'(x)\t\tx_lower\t\tx_upper\t\tx_mid\t\tf(x_mid)" << endl; //the headers
	int i = 1; //to count the iteration
	while ((x_upper - x_lower) >= ERROR) { //it continues until the difference between upper and lower bound is smaller than error tolerance level
		x_mid = (x_lower + x_upper) / 2; //finding the mid-point
		cout << i << "\t\t" << derivative(x_mid);
		if (i != 9 && i != 11) cout << "\t"; //to have a more aligned C++ output
		cout << "\t" << x_lower << "\t\t" << x_upper << "\t\t" << x_mid << "\t\t" << function(x_mid) << endl;
		if (derivative(x_mid) == 0.0) //checking whether the mid-point is the root
			break;

		else if (derivative(x_mid) * derivative(x_lower) < 0) //determining the new bounds
			x_upper = x_mid;
		else //determining the new bounds
			x_lower = x_mid;
		i++;
	}
	cout << endl << "The approximate solution by bisection method is: " << x_mid << endl;
}

int main() {
	cout.precision(4); //to show only 4 digits after zeros in the output, so that we have a better looking output table
	double x_low = -3, x_up = 3; //initial upper and lower bounds given in the question
	bisection(x_low, x_up);
	return 0;
}